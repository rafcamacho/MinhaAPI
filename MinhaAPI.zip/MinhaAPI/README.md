# MinhaApi

API de agendamentos com .NET 8 e MySQL.

Resumo do projeto
- CRUD b�sico para Usu�rios, Servi�os, Profissionais e Agendamentos.
- Soft delete implementado para Usu�rios, Servi�os e Profissionais (`IsDeleted`).
- Separa��o em camadas: Controllers ? Services ? Repositories ? DbContext (AppDbContext).
- Mapeamento EF Core via `OnModelCreating` para usar nomes de tabelas/colunas em min�sculas (compat�vel com o schema MySQL fornecido).

Como rodar localmente
1. Configurar vari�veis/connection string
- Arquivo `appsettings.json` cont�m `DefaultConnection`. Atualize se necess�rio:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=localhost;Database=minhaapidb;User=root;Password=Dev@2025#MySQL;"
}
```

2. Subir a aplica��o
- No terminal do projeto:

```sh
$env:ASPNETCORE_ENVIRONMENT="Development"
dotnet run
```

3. Swagger (UI) para testar
- Em ambiente de desenvolvimento o Swagger � habilitado.
- URL (exemplo): `https://localhost:5138/swagger` (a porta pode variar; verifique sa�da do `dotnet run`).

4. Postman
- Cole��o Postman dispon�vel em `postman/MinhaApi.postman_collection.json` no reposit�rio.
- Importe a cole��o no Postman e altere a vari�vel `baseUrl` se necess�rio.

Carregar vari�veis de ambiente (.env)
- O `Program.cs` j� l� um arquivo `.env` na raiz do projeto (sem sobrescrever vari�veis de ambiente existentes). Para usar, crie `.env` com as vari�veis descritas abaixo.

Op��es para carregar vari�veis (exemplos):

- Usar `.env` (recomendado)
  - Coloque `.env` na raiz do projeto (j� inclu�do no `.gitignore`). Depois apenas rode `dotnet run` � o `Program.cs` ir� carregar automaticamente.

- PowerShell (sess�o atual)
```powershell
$env:DB_HOST = "localhost"
$env:DB_NAME = "minhaapidb"
$env:DB_USER = "root"
$env:DB_PASS = "Dev@2025#MySQL"
dotnet run
```

- Bash / Linux / macOS (sess�o atual)
```bash
export DB_HOST=localhost
export DB_NAME=minhaapidb
export DB_USER=root
export DB_PASS='Dev@2025#MySQL'
dotnet run
```

- Carregar `.env` em Bash
```bash
set -a
source .env
set +a
dotnet run
```

- VSCode (launch.json) � exemplo de configura��o de depura��o
```json
{
  "version": "0.2.0",
  "configurations": [
    {
      "name": ".NET Core Launch (web)",
      "type": "coreclr",
      "request": "launch",
      "preLaunchTask": "build",
      "program": "${workspaceFolder}/bin/Debug/net8.0/MinhaApi.dll",
      "args": [],
      "envFile": "${workspaceFolder}/.env",
      "cwd": "${workspaceFolder}",
      "stopAtEntry": false
    }
  ]
}
```

Rotas dispon�veis
- Usuarios
  - GET  /api/usuarios          � lista usu�rios (n�o deletados)
  - GET  /api/usuarios/{id}     � obter usu�rio por id
  - POST /api/usuarios          � criar usu�rio
  - PUT  /api/usuarios          � atualizar usu�rio
  - DELETE /api/usuarios/{id}   � soft delete (IsDeleted = true)

- Servicos
  - GET  /api/servicos          � lista servi�os (n�o deletados)
  - GET  /api/servicos/{id}     � obter servi�o por id
  - POST /api/servicos          � criar servi�o
  - PUT  /api/servicos          � atualizar servi�o
  - DELETE /api/servicos/{id}   � soft delete

- Profissionais
  - GET  /api/profissionais     � lista profissionais (n�o deletados)
  - GET  /api/profissionais/{id}� obter profissional por id
  - POST /api/profissionais     � criar profissional
  - PUT  /api/profissionais     � atualizar profissional
  - DELETE /api/profissionais/{id} � soft delete

- Agendamentos
  - GET  /api/Agendamentos      � lista agendamentos
  - GET  /api/Agendamentos/{id} � obter agendamento por id
  - POST /api/Agendamentos      � criar agendamento
  - PUT  /api/Agendamentos      � atualizar agendamento
  - DELETE /api/Agendamentos/{id} � remover agendamento

Observa��es importantes
- IDs: `Usuario.Id` � `Guid` (armazenado como `binary(16)` no MySQL). `Servico.Id` e `Profissional.Id` s�o `int`.
- Antes de criar um agendamento, crie um usu�rio, servi�o e profissional e use os IDs retornados (o servi�o valida FKs antes de inserir).
- Senhas: atualmente armazenadas em texto. Para produ��o, implemente hashing (BCrypt/Argon2) e endpoints de autentica��o.
- SQL schema: se precisar recriar o banco, h� um arquivo `sql/schema_mysql.sql` com o DDL usado originalmente.

Arquitetura e estudo
- Pontos para estudar: ASP.NET Core, EF Core, DI, Repository pattern, DTOs, migrations, testes (xUnit), Docker, JWT.

Suporte
- Arquivo Postman: `postman/MinhaApi.postman_collection.json`
- Swagger UI: `https://localhost:{porta}/swagger` (verifique porta ap�s rodar a API)

Boa sorte ao testar � se precisar de scripts de seed, migra��es EF ou docker-compose, eu gero para voc�.


