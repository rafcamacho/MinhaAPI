﻿namespace MinhaApi.DTOs.Usuario;

public class UsuarioLoginDto
{
    public required string Email { get; set; }
    public required string Senha { get; set; }
}
