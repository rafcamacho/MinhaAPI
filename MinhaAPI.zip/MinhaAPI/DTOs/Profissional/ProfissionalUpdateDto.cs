namespace MinhaApi.DTOs.Profissional;

public class ProfissionalUpdateDto
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
}
