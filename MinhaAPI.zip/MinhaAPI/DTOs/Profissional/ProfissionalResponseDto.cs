namespace MinhaApi.DTOs.Profissional;

public class ProfissionalResponseDto
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
}
