﻿public class ServicoCreateDto
{
    public required string Nome { get; set; }
    public decimal Preco { get; set; }
}
